module github.com/sage-x-project/did-go

go 1.26.0

toolchain go1.26.8
